package mx.com.grupokm.crud.CrudAlexisNovella;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 
 * @author Alexis Novella Vidal
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class CrudAlexisNovellaApplicationTests {

	@Test
	public void contextLoads() {
	}

}
